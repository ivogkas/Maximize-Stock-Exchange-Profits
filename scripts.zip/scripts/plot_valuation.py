import os
import pandas as pd
from datetime import date, timedelta
from datetime import datetime
import datetime as dt
import matplotlib.pyplot as plt
import numpy as np


start_day = datetime.strptime("1960-01-01", '%Y-%m-%d')
end_day = datetime.strptime("2018-01-01", '%Y-%m-%d')
df_plot = pd.DataFrame(columns=["Date", "Valuation", "Balance"])
balance = 1
balance_plot = [(datetime.strptime("1960-1-1", '%Y-%m-%d'), 1)]


def find_balance(metoxi, column, d):
    f = open(metoxi)
    first_line = f.readline()
    value = 0
    for line in f:
        file_date = datetime.strptime(line.split(",")[0], '%Y-%m-%d')
        if file_date == d:
            value = line.split(",")[column]
            break
    f.close()
    return float(value)


def create_balance_file():
    global balance
    f = open('test_file.txt')
    first_line = f.readline()
    for line in f:
        # print(line.split(" ")[1].split("-")[1])
        transaction_day = datetime.strptime(line.split(" ")[0], '%Y-%m-%d')
        c = line.split(" ")[1].split("-")[1]
        if c == "open":
            col = 1
        elif c == "high":
            col = 2
        elif c == "low":
            col = 3
        elif c == 'close':
            col = 4
        metoxi = "Stocks/Stocks/" + line.split(" ")[2].lower() + ".us.txt"
        v = find_balance(metoxi, col, transaction_day)
        action = line.split(" ")[1].split("-")[0]
        if action == "sell":
            balance += v * float(line.split(" ")[3])
        else:
            balance -= v * float(line.split(" ")[3])
        balance_plot.append((transaction_day, balance))

    balance_plot.sort(key=lambda tup: tup[0])

    os.remove("balance_plot.txt")
    with open('balance_plot.txt', 'a') as the_file:
        for line in balance_plot:
            day = str(line[0]).split(" ")[0]
            balance = line[1]
            str_by_line = day + " " + str(balance)
            the_file.write(str_by_line + "\n")


def daily_value(metoxi):
    f = open(metoxi)
    first_line = f.readline()
    value = 0
    for line in f:
        file_date = datetime.strptime(line.split(",")[0], '%Y-%m-%d')
        if file_date <= start_day:
            value = line.split(",")[4]
    f.close()
    return float(value)


def total_daily_valuation():
    global start_day, end_day
    ex = "test_file.txt"
    stocks = []
    while start_day <= end_day:
        f = open(ex)
        first_line = f.readline()
        for line in f:
            if datetime.strptime(line.split(" ")[0], '%Y-%m-%d') == start_day:
                if line.split(" ")[1].split('-')[0] == "buy":
                    stocks.append((line.split(" ")[2], float(line.split(" ")[3])))
                elif line.split(" ")[1].split('-')[0] == "sell":
                    stocks.remove((line.split(" ")[2], float(line.split(" ")[3])))

        sum_daily_value = 0
        for i in stocks:
            metoxi = "Stocks/Stocks/" + i[0].lower() + ".us.txt"
            v = daily_value(metoxi) * i[1]
            sum_daily_value += v
        print(start_day, sum_daily_value)
        df_plot.loc[len(df_plot.index)] = [start_day, sum_daily_value, 1]
        start_day = start_day + dt.timedelta(days=1)
        f.close()


def daily_balance():
    f = open("balance_plot.txt")
    for line in f:
        day = datetime.strptime(line.split(" ")[0], '%Y-%m-%d')
        df_plot['Balance'] = np.where(df_plot['Date'] >= day, float(line.split(" ")[1]), df_plot['Balance'])
    f.close()


def create_plot():
    print(df_plot)
    plt.yscale('log')
    plt.fill_between(df_plot['Date'], df_plot["Valuation"], color="green", zorder=1)
    plt.fill_between(df_plot['Date'], df_plot["Balance"], color="blue", zorder=2)
    plt.legend(["Portfolio", "Balance"],  loc='upper left')
    plt.xlabel("Time")
    plt.ylabel("Valuation")
    plt.grid(True)
    plt.show()


create_balance_file()
total_daily_valuation()
daily_balance()
create_plot()
